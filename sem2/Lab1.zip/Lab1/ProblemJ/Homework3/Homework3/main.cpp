#include <iostream>
#include <stack>

using namespace std;

int main() {

	return 0;
}
